var React = require('react');

var Home = React.createClass({
  render: function() {
    return(
      <h2 className="text-center">
        All Todos
      </h2>
    )
  }
})

module.exports = Home;
