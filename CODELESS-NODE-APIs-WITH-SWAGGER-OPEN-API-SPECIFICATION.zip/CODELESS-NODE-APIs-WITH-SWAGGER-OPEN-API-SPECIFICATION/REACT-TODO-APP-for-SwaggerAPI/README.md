# React UI for Todo API
This React application is a sample frontend
This is Todo API server built with Swagger, part of the Node.js Codeless  API Creation: Up And Running With Swagger.
http://btreepress.com/blog/portfolio-items/codeless-node-apis-with-swagger-open-api-specification/
https://www.udemy.com/course/1076002/

## Getting Started
- Clone the repo.
- Install dependencies with `npm install`
- Launch the application with `webpack -w`
- Ensure you have the Todo API server  up and running
 
 